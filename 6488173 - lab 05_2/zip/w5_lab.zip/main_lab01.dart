import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

// This widget is the root of your application .
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Route ␣ Push ␣ Demo ",
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const FirstRoute(),
    );
  }
}

class FirstRoute extends StatelessWidget {
  const FirstRoute({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(" First ␣ Route "),
      ),
      body: Center(
        child: ElevatedButton(
          child: const Text("Open ␣ route "),
          onPressed: () {
// Navigate to second route when tapped .
            Navigator.push(context,
                MaterialPageRoute(builder: (context) => const SecondRoute()));
          },
        ),
      ),
    );
  }
}

class SecondRoute extends StatelessWidget {
  const SecondRoute({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(" Second ␣ Route "),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            Navigator.pop(context);
// Navigate back to first route when tapped .
          },
          child: const Text(" Go ␣ back ! "),
        ),
      ),
    );
  }
}
